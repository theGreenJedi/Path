<p>
    The stock price for <?=$name?>(<?=$symbol?>) is $<?=number_format($price, 2)?>
</p>