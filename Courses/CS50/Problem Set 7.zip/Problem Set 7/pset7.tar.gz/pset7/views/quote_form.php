<form action="quote.php" method="post">
    <fieldset>
        <div class="control-group">
            <input autofocus name="code" placeholder="Stock Symbol" type="text"/>
        </div>
        <div class="control-group">
            <button type="submit" class="btn">Search</button>
        </div>
    </fieldset>
</form>