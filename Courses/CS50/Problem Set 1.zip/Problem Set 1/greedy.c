# include <stdio.h>
# include <math.h>

int main(void)
{
    float changeOwed;
    int check;
    char invisibleChar;
    int count = 0;
	int numQ=0, numD=0, numN=0, numP=0;
    
      /***Run this loop until the user inputs a number greater than or equal to 0***/
    do{
          printf("0 hail, how much change is owed?\n");
        check = scanf("%f", &changeOwed); // returns 1 if the input is a number and returns 0 otherwise
        
        //Get's rid of any extra invisible characters if the input is a char/String
        do{
            scanf("%c",&invisibleChar);
        }while(invisibleChar != '\n');
            
    }while(check == 0 || !(changeOwed >=0 ));
    
    
    changeOwed *= 10000.0; //Converting the decimal to a more managable integer
    float a = changeOwed;
    int  c = (int) a;
    
    //Continue to do this loop until 
	while(c > 0){
	
	
		while(c >= 2500){
			count ++;
			numQ++;
			c = c - 2500;
		}
		
		while(c >= 1000){
			count ++;
			numD++;
			c = c - 1000;
		}
		
		while(c >= 500){
			count ++;
			numN++;
			c = c - 500;
		}
		
		while(c >= 100){
			count ++;
			numP++;
		c = c - 100;
		}

	}
    printf("%d\n", count);
 //	printf("Quarters: %d, Dimes:%d, Nickels:%d, Pennies:%d, total:%d, totalCount:%d", numQ, numD, numN, numP, numQ + numD + numN + numP , count);
   
    
}
