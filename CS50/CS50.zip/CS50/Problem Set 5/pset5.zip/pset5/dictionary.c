/**************************************************************************
 * dictionary.c
 *
 * cs50x
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 *************************************************************************/

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include "dictionary.h"


#define T_SIZE 26

// Defining the hash function to retrun the hash value aka the hash table index
int hash(const char *word);

// GLOBAL VARIABLES
unsigned int count_word = 0;
char word[LENGTH + 1];

//CREATING A STRUCT CALLED 'node'
typedef struct node 
{
    char *word;
    struct node *next;
} node;

//Creating the Hash table
node *hash_table[T_SIZE];




bool check(const char *word)
{
    node *newnode = malloc(sizeof(newnode));
    newnode = hash_table[hash(word)];
    
    while(newnode != NULL) 
    {
        if (strcasecmp(word, newnode->word) == 0)
	        return true;
        
        newnode = newnode->next;
    }
    return false;
}




bool load(const char *dictionary)
{
    
    int hash_value;
    
    //hash_table[T_SIZE+1]={NULL};
    for (int i = 0; i < T_SIZE; i++) 
    {
        hash_table[i] = NULL;
    }
    
    FILE *fp = fopen(dictionary, "r");
	if(fp == NULL){
	   return false;
	}

  

   
   while(!feof(fp))
    {
        fscanf(fp,"%s\n",word);
        
        node *nodep = malloc(sizeof(node));
        nodep->word = malloc(strlen(word) +1);
        strcpy(nodep->word,word);
    
        hash_value = hash(word);
  
        count_word++;
    
        if(hash_table[hash_value] == NULL)
        {
        	hash_table[hash_value] = nodep;
    	    nodep->next = NULL;
        }
        else 
        {
    	    nodep->next = hash_table[hash_value];
    	    hash_table[hash_value] = nodep;
        }
  }
  
  return true;
}



unsigned int size(void)
{
  return count_word;
}


bool unload(void)
{
    node *nodep;
    node *nextnodep;
    
    int i=0;
    while(i<T_SIZE)
    {
        nodep = hash_table[i];
        while (nodep != NULL)
        {
	        free(nodep->word);
	        
	        nextnodep  = nodep->next;
	        
	        free(nodep);
	        
	        nodep = nextnodep;
        }   
        hash_table[i] = NULL;
        i++;
    }
  
  return true;
}


int hash(const char *word) 
{
    
    int hash = tolower(word[0]) - 97;
    
    return hash % T_SIZE; 
}
