#include <stdio.h>


int main(void)
{
    int height;
    int check;
    char invisibleChar;
    int i;
    
    /***Run this loop until the user inputs a number between 0 - 23***/
    do{
        printf("Height: ");
        check = scanf("%d", &height); // returns 1 if the input is a number and returns 0 otherwise
        
        //Get's rid of any extra invisible characters if the input is a char/String
        do{
            scanf("%c",&invisibleChar);
        }while(invisibleChar != '\n');
            
    }while(check == 0 || !(height >=0 && height <= 23));
    
   /*** Create Pyramid ***/
   int numHash = 2;
   int j=0;
   for(i=0; i <height; i++)
   {
            //Print the correct number of spaces
            for(j=0; j<height + 1 - numHash; j++)
              printf(" ");
            
            //Print the correct number of Hash tags
            for(j=0; j<numHash; j++)
              printf("#");
            
            // print next line for the next row
            printf("\n");
            
            //Increment numHash by 1 for each iteration
            numHash++;
   }
  
    
}
