/****************************************************************************
 * resize.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Resizes a BMP by a specified factor.
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"




int main(int argc, char* argv[])
{
		
		if (argc > 4 || argc<4)
		{
				printf("Usage:resize n infile outputfile\n");
				return 1;
		}

		
		int factor = atoi(argv[1]);
		if(factor < 0 || factor > 100)
		{
				printf("The resize factor should be a positive integer <= 100.\n");
				return 2;
		}

		
		char* infile = argv[2];
		char* outputfile = argv[3];

	
		FILE* inptr = fopen(infile, "r");
		if (inptr == NULL){
				printf("Could not open %s.\n", infile);
				return 3;
		}

	
		FILE* outputptr = fopen(outputfile, "w");
		if (outputptr == NULL){
				fclose(inptr);
				fprintf(stderr, "Could not create %s.\n", outputfile);
				return 4;
		}

		
		BITMAPFILEHEADER bf;
		fread(&bf, sizeof(BITMAPFILEHEADER), 1, inptr);

		
		BITMAPINFOHEADER bi;
		fread(&bi, sizeof(BITMAPINFOHEADER), 1, inptr);

		
		if (bi.biCompression != 0|| bf.bfType != 0x4d42 || bf.bfOffBits != 54 || bi.biSize != 40 || 
						bi.biBitCount != 24 ){
				fclose(outputptr);
				fclose(inptr);
				fprintf(stderr, "Unsupported file format.\n");
				return 4;
		}

		
		
		BITMAPINFOHEADER output_bi;	
		BITMAPFILEHEADER output_bf;
		output_bi = bi;
		output_bf = bf;
		output_bi.biHeight = factor * bi.biHeight;
		output_bi.biWidth = factor * bi.biWidth;
		

		int output_padding =  (4 - (sizeof(RGBTRIPLE) * output_bi.biWidth ) % 4) % 4;
		int inputpadding =  (4 - (sizeof(RGBTRIPLE) * bi.biWidth ) % 4) % 4;
		

		
		output_bf.bfSize = (50 + 4) + output_bi.biWidth * 3 * abs(output_bi.biHeight) + abs(output_bi.biHeight) *  output_padding;
		output_bi.biSizeImage = ((((output_bi.biWidth * output_bi.biBitCount) + (30 +1)) & ~31) / 8) * abs(output_bi.biHeight);

		
		fwrite(&output_bf, sizeof(BITMAPFILEHEADER), 1, outputptr);

		
		fwrite(&output_bi, sizeof(BITMAPINFOHEADER), 1, outputptr);

		for (int i = 0, biHeight = abs(bi.biHeight); i < biHeight; i++)
		{
				// Write each line factor-times
				for(int n = 0; n < factor; n++)
				{
						// iterate over pixels in scanline
						for (int j = 0; j < bi.biWidth; j++)
						{
								// temporary storage
								RGBTRIPLE triple;

								// read RGB triple from infile
								fread(&triple, sizeof(RGBTRIPLE), 1, inptr);

								// write RGB triple to outputfile
								for(int m = 0; m < factor; m++) 
								{
										fwrite(&triple, sizeof(RGBTRIPLE), 1, outputptr);
								}
						}

						// skip over padding in infile
						fseek(inptr, inputpadding, SEEK_CUR);

						// then add it to outputfile
						for (int k = 0; k <output_padding; k++)
								fputc(0x00, outputptr);

						fseek(inptr, -(bi.biWidth * 3 + inputpadding ), SEEK_CUR);

				}
				fseek(inptr, bi.biWidth*3+inputpadding, SEEK_CUR);
		}
		fclose(inptr);
		fclose(outputptr);
		return 0;
}